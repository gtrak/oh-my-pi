# Fix the bug in `proxy.js`

The if and else branches are swapped.

The issue is in the `injectProxy` function.

Swap the if and else branch bodies back to their original positions.