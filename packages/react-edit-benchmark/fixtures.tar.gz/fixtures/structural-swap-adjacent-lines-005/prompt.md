# Fix the bug in `ReactOwnerStackFrames.js`

Two adjacent statements are in the wrong order.

The issue starts around line 14.

Swap the two adjacent lines back to their original order.