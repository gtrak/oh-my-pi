# Fix the bug in `ReactFlightClientConfigBundlerTurbopackBrowser.js`

A logical negation (`!`) was accidentally removed.

The issue is in the `addChunkDebugInfo` function.

Add back the missing logical negation (`!`).