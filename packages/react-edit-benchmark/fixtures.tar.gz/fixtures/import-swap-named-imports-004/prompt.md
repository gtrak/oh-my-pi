# Fix the bug in `ReactFiberLegacyContext.js`

Two named imports are swapped in a destructuring import.

Find and fix this issue.