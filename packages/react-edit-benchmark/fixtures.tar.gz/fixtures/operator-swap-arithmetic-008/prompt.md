# Fix the bug in `ReactFizzComponentStack.js`

There is a subtle bug in this file.

Track it down and fix it with a minimal edit.