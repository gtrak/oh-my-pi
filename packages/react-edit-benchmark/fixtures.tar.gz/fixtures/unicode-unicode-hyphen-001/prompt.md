# Fix the bug in `formatProdErrorMessage.js`

A string literal contains a lookalike unicode dash.

The issue is on line 24.

Replace the unicode dash with a plain ASCII hyphen.