# Fix the bug in `getHookNameForLocation.js`

A boolean operator is incorrect.

Find and fix this issue.