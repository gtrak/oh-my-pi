# Fix the bug in `index.js`

The if and else branches are swapped.

The fix may involve multiple lines.