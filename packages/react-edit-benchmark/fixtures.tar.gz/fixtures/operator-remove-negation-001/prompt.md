# Fix the bug in `prepareInjection.js`

A logical negation (`!`) was accidentally removed.

The issue is on line 12.

Add back the missing logical negation (`!`).