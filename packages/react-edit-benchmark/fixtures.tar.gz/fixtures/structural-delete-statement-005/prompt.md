# Fix the bug in `StackTraceView.js`

A critical statement was deleted from the code.

The issue starts around line 61.

Restore the deleted statement.