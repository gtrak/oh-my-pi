# Fix the bug in `UseEffectEvent.js`

A boolean operator is incorrect.

The issue is on line 5.

Use the intended boolean operator.