# Fix the bug in `SourceMapConsumer.js`

A string literal contains a lookalike unicode dash.

Find and fix this issue.