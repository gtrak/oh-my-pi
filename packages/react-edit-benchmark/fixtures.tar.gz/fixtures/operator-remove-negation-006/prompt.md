# Fix the bug in `backendManager.js`

A logical negation (`!`) was accidentally removed.

The issue is in the `registerRenderer` function.

Add back the missing logical negation (`!`).