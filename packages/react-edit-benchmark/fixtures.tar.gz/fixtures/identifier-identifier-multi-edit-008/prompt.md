# Fix the bug in `ReactFiberAsyncAction.js`

An identifier is consistently misspelled throughout this file.

Find all occurrences and fix them.