# Fix the bug in `reactPolling.js`

Two arguments in a call are swapped.

The issue is in the `startReactPolling` function.

Swap the two arguments to their original order.