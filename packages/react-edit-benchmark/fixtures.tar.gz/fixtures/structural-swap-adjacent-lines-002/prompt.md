# Fix the bug in `HorizontalPanAndZoomView.js`

Two adjacent statements are in the wrong order.

The issue is near the end of the file.

Swap the two adjacent lines back to their original order.