# Fix the bug in `index.js`

A numeric boundary has an off-by-one error.

Find and fix this issue.