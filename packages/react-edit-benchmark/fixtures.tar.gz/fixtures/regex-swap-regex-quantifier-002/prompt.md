# Fix the bug in `symbolicateSource.js`

A regex quantifier was swapped, changing whitespace matching.

The issue is in the `symbolicateSource` function.

Fix the ONE regex quantifier that was swapped (between `+` and `*`). Do not modify other quantifiers.