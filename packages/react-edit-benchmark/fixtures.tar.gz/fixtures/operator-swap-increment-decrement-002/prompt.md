# Fix the bug in `NativeEventsView.js`

An increment/decrement operator points the wrong direction.

The issue is near the end of the file.

Replace the increment/decrement operator with the intended one.