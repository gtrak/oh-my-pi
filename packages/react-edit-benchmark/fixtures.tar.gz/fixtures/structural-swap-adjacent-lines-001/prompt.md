# Fix the bug in `reactPolling.js`

Two adjacent statements are in the wrong order.

The issue starts around line 60.

Swap the two adjacent lines back to their original order.