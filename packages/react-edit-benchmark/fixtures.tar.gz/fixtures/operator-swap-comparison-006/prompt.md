# Fix the bug in `SidebarSelectedFiberInfo.js`

A comparison operator is subtly wrong.

The issue is in the `SidebarSelectedFiberInfo` function.

Swap the comparison operator to the correct variant.