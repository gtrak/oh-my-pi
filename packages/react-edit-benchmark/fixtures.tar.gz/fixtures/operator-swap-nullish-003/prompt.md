# Fix the bug in `ReactComponentStackFrame.js`

A nullish coalescing operator was swapped.

Find and fix this issue.