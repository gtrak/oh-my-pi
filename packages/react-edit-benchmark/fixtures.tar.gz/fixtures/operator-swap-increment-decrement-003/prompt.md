# Fix the bug in `ReactFlightClientConfigBundlerESM.js`

An increment/decrement operator points the wrong direction.

Find and fix this issue.