# Fix the bug in `ReactFiberComponentStack.js`

An identifier is misspelled in multiple separate locations.

Find and fix all occurrences of this issue.