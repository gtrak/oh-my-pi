# Fix the bug in `Element.js`

A boolean literal is inverted.

Find and fix this issue.