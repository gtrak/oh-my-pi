# Fix the bug in `RunReactCompiler.ts`

A regex quantifier was swapped, changing whitespace matching.

Find and fix this issue.