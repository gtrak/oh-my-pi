# Fix the bug in `SidebarSelectedFiberInfo.js`

An arithmetic operator was swapped.

The issue is in the `SidebarSelectedFiberInfo` function.

Correct the arithmetic operator.