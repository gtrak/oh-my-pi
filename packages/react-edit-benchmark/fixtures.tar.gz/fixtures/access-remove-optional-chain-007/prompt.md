# Fix the bug in `index.js`

Optional chaining was removed from a property access.

Find and fix this issue.