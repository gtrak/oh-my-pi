# Fix the bug in `useExtensionComponentsPanelVisibility.js`

A critical statement was deleted from the code.

The issue starts around line 18.

Restore the deleted statement.