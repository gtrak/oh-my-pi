# Fix the bug in `index.js`

Two named imports are swapped in a destructuring import.

Find and fix this issue.