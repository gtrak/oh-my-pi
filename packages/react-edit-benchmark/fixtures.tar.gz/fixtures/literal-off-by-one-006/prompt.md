# Fix the bug in `ReactFizzTreeContext.js`

A numeric boundary has an off-by-one error.

The issue is in the `pushTreeContext` function.

Fix the off-by-one error in the numeric literal or comparison.