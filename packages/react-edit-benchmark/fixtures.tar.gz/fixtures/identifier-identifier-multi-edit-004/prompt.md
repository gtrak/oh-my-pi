# Fix the bug in `InspectedElementSuspendedBy.js`

An identifier is consistently misspelled throughout this file.

Find all occurrences and fix them.