# Fix the bug in `ReactOwnerStackFrames.js`

A numeric boundary has an off-by-one error.

The issue is on line 31.

Fix the off-by-one error in the numeric literal or comparison.