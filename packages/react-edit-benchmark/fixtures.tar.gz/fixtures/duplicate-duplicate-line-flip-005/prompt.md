# Fix the bug in `shallowEqual.js`

A duplicated line contains a subtle literal/operator change.

The issue is on line 20.

Fix the literal or operator on the duplicated line.