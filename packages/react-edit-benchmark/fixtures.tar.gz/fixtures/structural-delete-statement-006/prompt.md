# Fix the bug in `CheckStringCoercion.js`

A critical statement was deleted from the code.

The issue is in the `typeName` function.

Restore the deleted statement.