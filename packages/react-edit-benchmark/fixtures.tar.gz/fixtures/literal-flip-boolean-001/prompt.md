# Fix the bug in `ReactDOMLegacyServerImpl.js`

A boolean literal is inverted.

The issue is on line 41.

Flip the boolean literal to the intended value.