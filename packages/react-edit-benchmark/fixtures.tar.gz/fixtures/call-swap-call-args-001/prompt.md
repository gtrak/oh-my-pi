# Fix the bug in `formatConsoleArguments.js`

Two arguments in a call are swapped.

The issue is on line 49.

Swap the two arguments to their original order.