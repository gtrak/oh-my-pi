# Fix the bug in `useCanvasInteraction.js`

Two named imports are swapped in a destructuring import.

Find and fix this issue.