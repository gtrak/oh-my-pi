# Fix the bug in `ReactFabricEventEmitter.js`

A critical statement was deleted from the code.

The issue is in the `extractPluginEvents` function.

Restore the deleted statement.