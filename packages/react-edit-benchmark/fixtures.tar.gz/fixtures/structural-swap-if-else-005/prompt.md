# Fix the bug in `ReactClientConsoleConfigPlain.js`

The if and else branches are swapped.

The issue starts around line 38.

Swap the if and else branch bodies back to their original positions.