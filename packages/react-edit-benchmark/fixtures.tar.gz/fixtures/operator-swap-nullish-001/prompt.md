# Fix the bug in `ElementBadges.js`

A nullish coalescing operator was swapped.

The issue is on line 32.

Use the intended nullish/logical operator.