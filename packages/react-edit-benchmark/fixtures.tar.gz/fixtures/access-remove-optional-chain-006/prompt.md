# Fix the bug in `evalInInspectedWindow.js`

Optional chaining was removed from a property access.

The issue is near the end of the file.

Restore the optional chaining operator (`?.`) at the ONE location where it was removed. Do not add optional chaining elsewhere.