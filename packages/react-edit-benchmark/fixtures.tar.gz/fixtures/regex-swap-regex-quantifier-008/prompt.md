# Fix the bug in `hook.js`

A regex quantifier was swapped, changing whitespace matching.

Find and fix this issue.