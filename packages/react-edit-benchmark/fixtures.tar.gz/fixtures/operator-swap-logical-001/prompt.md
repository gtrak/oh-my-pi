# Fix the bug in `ErrorView.js`

A boolean operator is incorrect.

The issue is on line 36.

Use the intended boolean operator.