# Fix the bug in `ReactFiberViewTransitionComponent.js`

An increment/decrement operator points the wrong direction.

The issue is on line 56.

Replace the increment/decrement operator with the intended one.