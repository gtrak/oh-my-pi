# Fix the bug in `GeneralSettings.js`

A regex quantifier was swapped, changing whitespace matching.

The issue is in the `getChangeLogUrl` function.

Fix the ONE regex quantifier that was swapped (between `+` and `*`). Do not modify other quantifiers.