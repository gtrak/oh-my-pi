# Fix the bug in `SchedulingEventsView.js`

An arithmetic operator was swapped.

The issue is near the end of the file.

Correct the arithmetic operator.